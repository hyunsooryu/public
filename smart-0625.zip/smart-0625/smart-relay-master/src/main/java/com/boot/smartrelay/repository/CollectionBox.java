package com.boot.smartrelay.repository;

public class CollectionBox {
    public static final String ADMIN_BOX_COLLECCTION = "adminDevice";
    public static final String USER_COLLECTION = "user";
    public static final String USER_DEVICE_COLLECTION = "userDevice";
    public static final String PACKET_LIST_COLLECTION = "packetList";
}
