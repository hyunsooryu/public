package com.boot.smartrelay.config;

/**
 *
 * docker exec -i -t mongo_boot bash
 */
public class MongoConfig {

}
