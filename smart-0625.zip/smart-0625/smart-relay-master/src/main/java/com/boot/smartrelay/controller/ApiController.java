package com.boot.smartrelay.controller;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.smartrelay.beans.User;

import lombok.RequiredArgsConstructor;

@RestController("/api")
@RequiredArgsConstructor
public class ApiController {
	
	@Resource(name="loginUser")
    private User loginUser;
	
	
	@PostMapping("/modifyLargeSector")
	public String modifyLargeSector() {
		
		
		
		return null;
	}
	
	@PostMapping("/modifySmallSector")
	public String modifySmallSector() {
		
		
		return null;	
	}
}
