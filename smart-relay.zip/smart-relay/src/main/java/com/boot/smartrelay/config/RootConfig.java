package com.boot.smartrelay.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import java.util.HashMap;
import java.util.Map;

public class RootConfig {

    @Profile("local")
    @Configuration
    public static class LocalRootConfig{
        public LocalRootConfig(){
            System.out.println("Local Root Config");
        }

        @Bean
        public Map<String, String> varRoot(){
            Map<String, String> map = new HashMap<>();
            map.put("https", "localhost:443/");
            map.put("http", "localhost:10010/");
            return map;
        }
    }


}
