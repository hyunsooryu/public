package com.boot.smartrelay.config;

import com.boot.smartrelay.beans.AdminUser;
import com.boot.smartrelay.beans.User;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.annotation.RequestScope;
import org.springframework.web.context.annotation.SessionScope;

@Configuration
public class BeanConfig {

    @Bean(name="loginAdminUser")
    @SessionScope
    public AdminUser loginAdminUser(){
        System.out.println("loginAdminUser - 세션 입니다.");
        return new AdminUser();
    }

    @Bean
    @SessionScope
    public User loginUser(){
        System.out.println("loginUser - 세션 입니다.");
        return new User();
    }
}
