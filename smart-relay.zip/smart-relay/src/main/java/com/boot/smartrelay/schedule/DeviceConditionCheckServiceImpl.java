package com.boot.smartrelay.schedule;

import com.boot.smartrelay.beans.DeviceStatus;
import com.boot.smartrelay.beans.PacketList;
import com.boot.smartrelay.repository.CollectionBox;
import com.boot.smartrelay.repository.DeviceStatusMemoryRepository;
import com.boot.smartrelay.repository.DeviceStatusRedisRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.ConcurrentMap;

import static org.springframework.data.mongodb.core.query.Criteria.where;

@Component
@RequiredArgsConstructor
public class DeviceConditionCheckServiceImpl implements DeviceConditionCheckService {

    final DeviceStatusMemoryRepository deviceStatusMemoryRepository;

    final MongoTemplate mongoTemplate;

    final ConcurrentMap<String, Boolean> ON_DEVICE_MAP;

    @Scheduled(fixedRate = 60000)
    @Override
    public void deviceServiceCheck(){
        List<List<String>> status = deviceStatusMemoryRepository.getDevicesOnOrOff();


        System.out.println("Condition checker is working");

        List<String> on = status.get(0);
        List<String> off = status.get(1);

        System.out.println("---------현재 운영중인 디바이스 키----------");
        on.forEach((deviceId)-> {
            ON_DEVICE_MAP.put(deviceId, true);
            System.out.println("deviceId: " + deviceId);
        });
        System.out.println("-------------------------------------");
        System.out.println("---------현재 운영이 중단 된 디바이스 키----------");
        off.forEach((deviceId)-> {
            ON_DEVICE_MAP.put(deviceId, false);
            System.out.println("deviceId: " + deviceId);
        });
        if(off.size() >= 1) {
            mongoTemplate.remove(Query.query(where("deviceId").in(off)), PacketList.class, CollectionBox.PACKET_LIST_COLLECTION);
        }

        System.out.println("-------------------------------------------");

    }

    public boolean checkIsNowAliveDevice(String deviceId){
        boolean flg =  ON_DEVICE_MAP.containsKey(deviceId);
        if(!flg)return false;
        flg = ON_DEVICE_MAP.getOrDefault(deviceId, false);
        return flg;
    }


}
